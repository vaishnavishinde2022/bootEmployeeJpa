package com.employee.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/*
 * @Component annotation is used to denote a class as a component.
 * 
 * Bellow EmpModel class is a model to interact with database.
 */
@Component
public class EmpModel 
{
	/*
	 * @Autowired annotation is used for dependency injection at run time.
	 */
	@Autowired
	EmployeeRepo obj;
   public String saveEmpInfo(String Name,String Email,String Address,String Department,String Designation)
   {
	   Employee emp1=new Employee();
	   
	   emp1.setName(Name);
	   emp1.setEmail(Email);
	   emp1.setAddress(Address);
	   emp1.setDepartment(Department);
	   emp1.setDesignation(Designation);
	   
	   obj.save(emp1);
	   return "saved";
	   
	  
	   
	   
   }
}
