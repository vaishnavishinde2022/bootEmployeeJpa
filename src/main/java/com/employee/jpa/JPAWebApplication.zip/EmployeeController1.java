package com.employee.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmployeeController1
{
	@Autowired
	EmpModel obj;
	
	@RequestMapping("/employee")
   public String showEmpJsp()
   {
	   return "employee.jsp";
   }
	
	@PostMapping("/details")
	
	public String getEmpInfo(@RequestParam("Name")String Name,@RequestParam("Email") String Email,@RequestParam("Address")String Address,@RequestParam("Department")String Department,@RequestParam("Designation")String Designation,ModelMap modelmap)
	{
	  String msg= obj.saveEmpInfo(Name,Email,Address,Department,Designation);
	  
	  if(msg.equals("saved"))
	  {
		 
		  modelmap.put("Name", Name);
		  modelmap.put("Email", Email);
		  modelmap.put("Department",Department );
		  
		  return "employee.jsp";
		  
		  
		  
	  }
	  
	  return "error.jsp";
	}
}
